import asyncio
import sys

print("=== Старт бота ===", flush=True)

# Токен бота
BOT_TOKEN = "8290618352:AAGE4jpB5x3B2EaXS-HUTZoRwQvNpU4oyOU"

print(f"Токен установлен (длина: {len(BOT_TOKEN)})", flush=True)

try:
    from aiogram import Bot, Dispatcher, types
    from aiogram.filters import Command
    print("aiogram загружен", flush=True)
except Exception as e:
    print(f"Ошибка импорта aiogram: {e}", flush=True)
    sys.exit(1)

try:
    from TelegramGifts import TelegramGifts
    print("TelegramGifts загружен", flush=True)
except Exception as e:
    print(f"Ошибка импорта TelegramGifts: {e}", flush=True)
    sys.exit(1)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

print("Инициализация TelegramGifts (лёгкий режим)...", flush=True)
try:
    gifts = TelegramGifts(cache_mode="http", asset_mode="lazy")
    print("TelegramGifts готов", flush=True)
except Exception as e:
    print(f"Ошибка инициализации TelegramGifts: {e}", flush=True)
    gifts = None

tracked: dict[int, list[str]] = {}


@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    await message.answer(
        "Бот мониторинга NFT-подарков Telegram\n\n"
        "/price <название> — текущий floor\n"
        "/track <название> — добавить в отслеживание\n"
        "/list — список отслеживания\n"
        "/untrack <название> — убрать из отслеживания"
    )


@dp.message(Command("price"))
async def cmd_price(message: types.Message):
    if gifts is None:
        await message.answer("Библиотека подарков не загрузилась")
        return
    name = message.text.replace("/price", "").strip()
    if not name:
        await message.answer("Пример: /price Artisan Brick")
        return
    try:
        info = gifts.get_gift(name)
        if not info:
            await message.answer(f"Подарок «{name}» не найден")
            return
        prices = info.get("prices", {})
        text = (
            f"<b>{info.get('full_name', name)}</b>\n"
            f"Тип: {info.get('type', '—')}\n"
            f"Supply: {info.get('supply', '—')}\n\n"
            f"Floor (TGMrkt): {prices.get('tgmrkt_price_ton', '—')} TON\n"
            f"Portals: {prices.get('portal_price_ton', '—')} TON\n"
            f"GetGems: {prices.get('getgems_price_ton', '—')} TON"
        )
        await message.answer(text, parse_mode="HTML")
    except Exception as e:
        await message.answer(f"Ошибка: {e}")


@dp.message(Command("track"))
async def cmd_track(message: types.Message):
    name = message.text.replace("/track", "").strip()
    if not name:
        await message.answer("Пример: /track Plush Pepe")
        return
    uid = message.from_user.id
    tracked.setdefault(uid, [])
    if name.lower() in [n.lower() for n in tracked[uid]]:
        await message.answer(f"«{name}» уже отслеживается")
        return
    tracked[uid].append(name)
    await message.answer(f"Добавил «{name}» в отслеживание")


@dp.message(Command("untrack"))
async def cmd_untrack(message: types.Message):
    name = message.text.replace("/untrack", "").strip()
    uid = message.from_user.id
    if uid not in tracked or not tracked[uid]:
        await message.answer("Список пуст")
        return
    tracked[uid] = [n for n in tracked[uid] if n.lower() != name.lower()]
    await message.answer(f"Убрал «{name}»")


@dp.message(Command("list"))
async def cmd_list(message: types.Message):
    uid = message.from_user.id
    items = tracked.get(uid, [])
    if not items:
        await message.answer("Список пуст")
        return
    await message.answer("Отслеживаю:\n" + "\n".join(f"• {n}" for n in items))


async def monitor_loop():
    if gifts is None:
        return
    last_prices = {}
    while True:
        try:
            for uid, names in list(tracked.items()):
                for name in names:
                    try:
                        info = gifts.get_gift(name)
                        if not info:
                            continue
                        price = info.get("prices", {}).get("tgmrkt_price_ton")
                        key = f"{uid}:{name.lower()}"
                        if key in last_prices and price and last_prices[key] != price:
                            await bot.send_message(
                                uid,
                                f"Цена изменилась!\n"
                                f"<b>{info.get('full_name')}</b>\n"
                                f"Было: {last_prices[key]} → Стало: {price} TON",
                                parse_mode="HTML"
                            )
                        if price:
                            last_prices[key] = price
                    except Exception:
                        pass
        except Exception:
            pass
        await asyncio.sleep(180)


async def main():
    print("Запускаю polling...", flush=True)
    asyncio.create_task(monitor_loop())
    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"Критическая ошибка: {e}", flush=True)
        sys.exit(1)
